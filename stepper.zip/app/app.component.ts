import { Component,  OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {MatInputModule} from '@angular/material';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {
  
  nameFormGroup:FormGroup;
  addressFormGroup:FormGroup;
 stateFormGroup:FormGroup;
countryFormGroup:FormGroup;
pincodeFormGroup:FormGroup;
  constructor(private fb: FormBuilder) {}

  ngOnInit() {

    this.nameFormGroup=this.fb.group({
      name:['',Validators.required]

    });
    this.addressFormGroup=this.fb.group({
      address:['',Validators.required]
    });
    this.stateFormGroup=this.fb.group({
      state:['',Validators.required]

    });
  
    this.countryFormGroup=this.fb.group({
      country:['',Validators.required]

    });
    this.pincodeFormGroup=this.fb.group({
      pincode:['',Validators.required]

    });
  
  
  }


  public imagePath;
  imgURL: any;
  public message: string;
 
  preview(files) {
    if (files.length === 0)
      return;
 
    var mimeType = files[0].type;
    if (mimeType.match(/image\/*/) == null) {
      this.message = "Only images are supported.";
      return;
    }
 
    var reader = new FileReader();
    this.imagePath = files;
    reader.readAsDataURL(files[0]); 
    reader.onload = (_event) => { 
      this.imgURL = reader.result; 
    }
  }


}